import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import type { Role } from "@/pages/Index";

interface Props {
  onClose: () => void;
}

const UserModal = ({ onClose }: Props) => {
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<Role>("scanner");
  const [name, setName] = useState("");
  const [saving, setSaving] = useState(false);

  const save = async () => {
    const e = email.trim().toLowerCase();
    if (!e || !e.includes("@")) {
      toast.error("Please enter a valid email.");
      return;
    }
    setSaving(true);
    const { error } = await supabase
      .from("approved_users")
      .insert({ email: e, role, name: name.trim() || null });
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("User approved. They can now sign up with this email.");
    onClose();
  };

  return (
    <div className="sheet-modal" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="sheet-inner">
        <div className="handle" />
        <div className="mhead">
          <h2>Add User</h2>
          <button className="btn-ico" onClick={onClose}>
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M18 6 6 18M6 6l12 12" />
            </svg>
          </button>
        </div>
        <div className="mbody">
          <div className="fld">
            <label>Email Address</label>
            <input
              className="input-os"
              type="email"
              autoCapitalize="none"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="colleague@overstory.com"
            />
          </div>
          <div className="fld" style={{ marginTop: 12 }}>
            <label>Role</label>
            <select className="select-os" value={role} onChange={(e) => setRole(e.target.value as Role)}>
              <option value="scanner">Scanner — can capture leads only</option>
              <option value="admin">Admin — full access</option>
            </select>
          </div>
          <div className="fld" style={{ marginTop: 12 }}>
            <label>Name (optional)</label>
            <input
              className="input-os"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Becca"
            />
          </div>
        </div>
        <div className="mfoot">
          <button className="btn-os btn-s" style={{ flex: 1 }} onClick={onClose}>Cancel</button>
          <button className="btn-os btn-p" style={{ flex: 2 }} onClick={save} disabled={saving}>
            {saving ? <div className="spin" /> : "Add User"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default UserModal;
