import { useState } from "react";
import logo from "@/assets/overstory-logo.jpg";
import { supabase } from "@/integrations/supabase/client";

const LoginScreen = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    setErr("");
    const e = email.trim().toLowerCase();
    if (!e || !e.includes("@")) {
      setErr("Please enter a valid email address.");
      return;
    }
    if (password.length < 6) {
      setErr("Password must be at least 6 characters.");
      return;
    }
    setLoading(true);
    try {
      if (mode === "signup") {
        // Verify approval first
        const { data: approved } = await supabase.rpc("is_email_approved", { _email: e });
        if (!approved) {
          setErr("This email is not authorised. Contact your admin.");
          setLoading(false);
          return;
        }
        const { error } = await supabase.auth.signUp({
          email: e,
          password,
          options: { emailRedirectTo: `${window.location.origin}/` },
        });
        if (error) {
          setErr(error.message);
        } else {
          // Try immediate sign-in (auto-confirm typically off; show message)
          const { error: signInErr } = await supabase.auth.signInWithPassword({ email: e, password });
          if (signInErr) {
            setErr("Account created. Check your email to confirm, then sign in.");
            setMode("signin");
          }
        }
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email: e, password });
        if (error) setErr(error.message);
      }
    } catch (e: unknown) {
      setErr(e instanceof Error ? e.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-screen">
      <div style={{ marginBottom: 28 }}>
        <img src={logo} alt="Overstory" style={{ height: 38, width: "auto" }} />
      </div>
      <div className="login-card">
        <h2 style={{ fontFamily: "'Syne',sans-serif", fontSize: 18, fontWeight: 800, marginBottom: 4 }}>
          {mode === "signin" ? "Welcome back" : "Create your account"}
        </h2>
        <p style={{ fontSize: 13, color: "hsl(var(--text-2))", marginBottom: 20 }}>
          {mode === "signin"
            ? "Sign in with your work email to continue"
            : "Your email must be approved by an admin"}
        </p>
        <div className="fld">
          <label>Work Email</label>
          <input
            className="input-os"
            type="email"
            value={email}
            placeholder="you@overstory.com"
            autoCapitalize="none"
            autoCorrect="off"
            onChange={(e) => setEmail(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && submit()}
          />
        </div>
        <div className="fld" style={{ marginTop: 11 }}>
          <label>Password</label>
          <input
            className="input-os"
            type="password"
            value={password}
            placeholder="••••••••"
            onChange={(e) => setPassword(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && submit()}
          />
        </div>
        <button
          className="btn-os btn-p btn-full"
          style={{ marginTop: 16 }}
          disabled={loading}
          onClick={submit}
        >
          {loading ? <div className="spin" /> : mode === "signin" ? "Sign In" : "Create Account"}
        </button>
        {err && (
          <div style={{ color: "hsl(var(--red))", fontSize: 13, textAlign: "center", marginTop: 12 }}>
            {err}
          </div>
        )}
        <div style={{ textAlign: "center", marginTop: 14 }}>
          <button
            className="btn-g"
            onClick={() => {
              setErr("");
              setMode(mode === "signin" ? "signup" : "signin");
            }}
          >
            {mode === "signin" ? "First time? Create an account" : "Already have an account? Sign in"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default LoginScreen;
