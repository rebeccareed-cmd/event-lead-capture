import { useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import type { EventRow, LeadRow } from "./LeadApp";

interface Props {
  userId: string;
  leads: LeadRow[];
  events: EventRow[];
  onUpdated: () => void;
}

const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;

const MyLeads = ({ userId, leads, events, onUpdated }: Props) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const [draftAnswers, setDraftAnswers] = useState<Record<string, string>>({});
  const [savingId, setSavingId] = useState<string | null>(null);
  const [listeningId, setListeningId] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);

  const myRecent = useMemo(() => {
    const cutoff = Date.now() - SEVEN_DAYS_MS;
    return leads.filter(
      (l) => l.scanned_by === userId && new Date(l.created_at).getTime() >= cutoff
    );
  }, [leads, userId]);

  // Group by event name (or "No Event")
  const grouped = useMemo(() => {
    const map = new Map<string, LeadRow[]>();
    myRecent.forEach((l) => {
      const key = l.event_name || "No Event";
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(l);
    });
    return Array.from(map.entries());
  }, [myRecent]);

  const startEdit = (lead: LeadRow) => {
    setEditingId(lead.id);
    setDraft(lead.notes || "");
    setDraftAnswers({ ...(lead.answers || {}) });
  };
  const cancelEdit = () => {
    if (listeningId) {
      recognitionRef.current?.stop();
      setListeningId(null);
    }
    setEditingId(null);
    setDraft("");
    setDraftAnswers({});
  };

  const saveEdit = async (leadId: string) => {
    setSavingId(leadId);
    const { error } = await supabase
      .from("leads")
      .update({
        notes: draft.trim() || null,
        answers: draftAnswers,
      })
      .eq("id", leadId);
    setSavingId(null);
    if (error) {
      toast.error(error.message);
      return;
    }
    if (listeningId === leadId) {
      recognitionRef.current?.stop();
      setListeningId(null);
    }
    setEditingId(null);
    setDraft("");
    setDraftAnswers({});
    toast.success("Lead updated");
    onUpdated();
  };


  const toggleDictation = (leadId: string) => {
    if (listeningId === leadId) {
      recognitionRef.current?.stop();
      return;
    }
    const SR: any =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) {
      toast.error("Voice dictation isn't supported in this browser.");
      return;
    }
    const rec = new SR();
    rec.continuous = true;
    rec.interimResults = false;
    rec.lang = navigator.language || "en-US";
    rec.onresult = (e: any) => {
      let chunk = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) chunk += e.results[i][0].transcript;
      }
      if (chunk) {
        setDraft((prev) =>
          prev ? prev.replace(/\s+$/, "") + " " + chunk.trim() : chunk.trim()
        );
      }
    };
    rec.onerror = (e: any) => {
      if (e.error && e.error !== "no-speech" && e.error !== "aborted") {
        toast.error("Dictation error: " + e.error);
      }
    };
    rec.onend = () => setListeningId(null);
    recognitionRef.current = rec;
    try {
      rec.start();
      setListeningId(leadId);
    } catch (err) {
      console.warn(err);
    }
  };

  if (myRecent.length === 0) {
    return (
      <div className="view">
        <div className="card-os">
          <div style={{ textAlign: "center", padding: "32px 12px" }}>
            <h3 className="font-heading" style={{ fontSize: 18, fontWeight: 700, marginBottom: 8 }}>
              No leads yet this week
            </h3>
            <p style={{ fontSize: 14, color: "hsl(var(--text-3))" }}>
              No leads captured in the last 7 days. Head to the Scan tab to get started.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="view">
      <div className="seclbl">My Leads · Last 7 Days</div>

      {grouped.map(([eventName, evLeads]) => (
        <div key={eventName} style={{ marginBottom: 18 }}>
          {grouped.length > 1 && (
            <div className="clabel" style={{ marginBottom: 8, marginTop: 4 }}>
              {eventName}{" "}
              <span style={{ color: "hsl(var(--text-3))", fontWeight: 500 }}>
                · {evLeads.length} lead{evLeads.length !== 1 ? "s" : ""}
              </span>
            </div>
          )}
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {evLeads.map((l) => {
              const fullName =
                [l.first_name, l.last_name].filter(Boolean).join(" ") || "—";
              const date = new Date(l.created_at).toLocaleDateString("en-US", {
                year: "numeric",
                month: "short",
                day: "numeric",
              });
              const ev = events.find((e) => e.id === l.event_id);
              const qTags = Object.entries(l.answers || {}).map(([k, v]) => {
                const q = ev?.questions?.find((qq) => qq.id === k);
                return (
                  <span key={k} className="tag" title={q?.label || k}>
                    {String(v)}
                  </span>
                );
              });
              const isEditing = editingId === l.id;
              const isListening = listeningId === l.id;
              const isSaving = savingId === l.id;

              return (
                <div className="leadcard" key={l.id}>
                  <div
                    className="font-heading"
                    style={{ fontSize: 15, fontWeight: 700, marginBottom: 2 }}
                  >
                    {fullName}
                  </div>
                  <div
                    style={{
                      fontSize: 13,
                      color: "hsl(var(--brand-mid))",
                      marginBottom: 5,
                    }}
                  >
                    {l.email || "—"}
                  </div>
                  <div
                    style={{
                      fontSize: 12,
                      color: "hsl(var(--text-3))",
                      marginBottom: 8,
                    }}
                  >
                    {l.company || ""}
                    {l.company && l.title ? " · " : ""}
                    {l.title || ""}
                    {l.company || l.title ? "  ·  " : ""}
                    {date}
                  </div>
                  {isEditing && ev?.questions?.length ? (
                    <div
                      style={{
                        marginBottom: 10,
                        padding: 10,
                        background: "hsl(var(--border-soft) / 0.4)",
                        borderRadius: 8,
                      }}
                    >
                      <div
                        style={{
                          fontSize: 12,
                          fontWeight: 600,
                          color: "hsl(var(--text-2))",
                          marginBottom: 8,
                        }}
                      >
                        Qualifier Answers
                      </div>
                      {ev.questions.map((q) => (
                        <div key={q.id} style={{ marginBottom: 12 }}>
                          <span
                            style={{
                              fontSize: 13,
                              fontWeight: 500,
                              marginBottom: 6,
                              display: "block",
                            }}
                          >
                            {q.label}
                          </span>
                          <div className="pillrow">
                            {q.options.map((opt) => (
                              <div
                                key={opt}
                                className={
                                  "pill" + (draftAnswers[q.id] === opt ? " on" : "")
                                }
                                onClick={() =>
                                  setDraftAnswers((prev) => ({
                                    ...prev,
                                    [q.id]:
                                      prev[q.id] === opt ? "" : opt,
                                  }))
                                }
                              >
                                {opt}
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : qTags.length > 0 ? (
                    <div
                      onClick={() => startEdit(l)}
                      style={{
                        display: "flex",
                        flexWrap: "wrap",
                        gap: 5,
                        marginBottom: 10,
                        cursor: "pointer",
                      }}
                      title="Tap to edit"
                    >
                      {qTags}
                    </div>
                  ) : ev?.questions?.length ? (
                    <button
                      onClick={() => startEdit(l)}
                      style={{
                        cursor: "pointer",
                        fontSize: 12,
                        color: "hsl(var(--text-3))",
                        display: "flex",
                        gap: 6,
                        alignItems: "center",
                        padding: "6px 10px",
                        background: "transparent",
                        border: "1.5px dashed hsl(var(--border-soft))",
                        borderRadius: 8,
                        marginBottom: 10,
                        fontFamily: "inherit",
                      }}
                    >
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M12 5v14M5 12h14" />
                      </svg>
                      Add qualifier answers
                    </button>
                  ) : null}


                  {/* Notes section */}
                  {isEditing ? (
                    <div
                      style={{
                        marginTop: 4,
                        padding: 10,
                        background: "hsl(var(--border-soft) / 0.4)",
                        borderRadius: 8,
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                          marginBottom: 8,
                        }}
                      >
                        <span
                          style={{
                            fontSize: 12,
                            fontWeight: 600,
                            color: "hsl(var(--text-2))",
                          }}
                        >
                          Notes
                        </span>
                        <button
                          type="button"
                          className={"btn-os btn-s" + (isListening ? " btn-p" : "")}
                          style={{ padding: "6px 10px", fontSize: 12, gap: 5 }}
                          onClick={() => toggleDictation(l.id)}
                          title={isListening ? "Stop dictation" : "Start voice dictation"}
                        >
                          {isListening ? (
                            <>
                              <span className="rec-dot" />
                              Listening…
                            </>
                          ) : (
                            <>
                              <svg
                                width="12"
                                height="12"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2"
                              >
                                <rect x="9" y="2" width="6" height="12" rx="3" />
                                <path d="M5 10a7 7 0 0 0 14 0" />
                                <line x1="12" y1="19" x2="12" y2="22" />
                              </svg>
                              Dictate
                            </>
                          )}
                        </button>
                      </div>
                      <textarea
                        className="input-os"
                        rows={3}
                        autoFocus
                        style={{
                          resize: "vertical",
                          minHeight: 70,
                          fontFamily: "inherit",
                          fontSize: 13,
                        }}
                        value={draft}
                        onChange={(e) => setDraft(e.target.value)}
                        placeholder="Add any context from your conversation..."
                      />
                      <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
                        <button
                          className="btn-os btn-s"
                          style={{ flex: 1, fontSize: 13 }}
                          onClick={cancelEdit}
                          disabled={isSaving}
                        >
                          Cancel
                        </button>
                        <button
                          className="btn-os btn-p"
                          style={{ flex: 1, fontSize: 13 }}
                          onClick={() => saveEdit(l.id)}
                          disabled={isSaving}
                        >
                          {isSaving ? <div className="spin" /> : "Save"}
                        </button>
                      </div>
                    </div>
                  ) : l.notes ? (
                    <div
                      onClick={() => startEdit(l)}
                      style={{
                        cursor: "pointer",
                        fontSize: 12,
                        color: "hsl(var(--text-2))",
                        display: "flex",
                        gap: 6,
                        alignItems: "flex-start",
                        padding: "8px 10px",
                        background: "hsl(var(--border-soft) / 0.4)",
                        borderRadius: 8,
                        opacity: 0.9,
                      }}
                      title="Tap to edit notes"
                    >
                      <svg
                        width="13"
                        height="13"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        style={{ flexShrink: 0, marginTop: 1 }}
                      >
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                        <polyline points="14 2 14 8 20 8" />
                        <line x1="8" y1="13" x2="16" y2="13" />
                        <line x1="8" y1="17" x2="13" y2="17" />
                      </svg>
                      <span
                        style={{
                          whiteSpace: "pre-wrap",
                          wordBreak: "break-word",
                          flex: 1,
                        }}
                      >
                        {l.notes}
                      </span>
                    </div>
                  ) : (
                    <button
                      onClick={() => startEdit(l)}
                      style={{
                        cursor: "pointer",
                        fontSize: 12,
                        color: "hsl(var(--text-3))",
                        display: "flex",
                        gap: 6,
                        alignItems: "center",
                        padding: "8px 10px",
                        background: "transparent",
                        border: "1.5px dashed hsl(var(--border-soft))",
                        borderRadius: 8,
                        width: "100%",
                        fontFamily: "inherit",
                      }}
                    >
                      <svg
                        width="13"
                        height="13"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <path d="M12 5v14M5 12h14" />
                      </svg>
                      Add notes
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
};

export default MyLeads;
