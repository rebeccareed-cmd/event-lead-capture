import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import type { EventRow, Question, Attendee, TeamMember } from "./LeadApp";

interface Props {
  editing: EventRow | null;
  team: TeamMember[];
  onClose: () => void;
}


const todayISO = () => new Date().toISOString().slice(0, 10);
const newQid = () => "q" + Date.now() + "_" + Math.random().toString(36).slice(2, 6);

const EventModal = ({ editing, team, onClose }: Props) => {
  const [name, setName] = useState(editing?.name || "");
  const [meta, setMeta] = useState(editing?.meta || "");
  const [eventType, setEventType] = useState(editing?.event_type || "");
  const [organizer, setOrganizer] = useState(editing?.organizer || "");
  const [startDate, setStartDate] = useState(editing?.start_date || todayISO());
  const [endDate, setEndDate] = useState(editing?.end_date || todayISO());
  const [questions, setQuestions] = useState<Question[]>(
    editing?.questions?.length ? editing.questions : [{ id: newQid(), label: "", options: [""] }]
  );
  // Selected team_member emails (lowercase) — picker is keyed off email
  const [selectedEmails, setSelectedEmails] = useState<Set<string>>(() => {
    const init = new Set<string>();
    (editing?.attendees || []).forEach((a) => {
      if (a.email) init.add(a.email.toLowerCase());
    });
    return init;
  });
  const [saving, setSaving] = useState(false);

  const toggleAttendee = (email: string) => {
    const key = email.toLowerCase();
    const next = new Set(selectedEmails);
    if (next.has(key)) next.delete(key);
    else next.add(key);
    setSelectedEmails(next);
  };


  const addQ = () => setQuestions([...questions, { id: newQid(), label: "", options: [""] }]);
  const removeQ = (id: string) => setQuestions(questions.filter((q) => q.id !== id));
  const updateQ = (id: string, patch: Partial<Question>) =>
    setQuestions(questions.map((q) => (q.id === id ? { ...q, ...patch } : q)));
  const addOpt = (id: string) =>
    updateQ(id, { options: [...questions.find((q) => q.id === id)!.options, ""] });
  const updateOpt = (id: string, idx: number, val: string) => {
    const q = questions.find((x) => x.id === id)!;
    const opts = [...q.options];
    opts[idx] = val;
    updateQ(id, { options: opts });
  };
  const removeOpt = (id: string, idx: number) => {
    const q = questions.find((x) => x.id === id)!;
    updateQ(id, { options: q.options.filter((_, i) => i !== idx) });
  };

  const save = async () => {
    if (!name.trim()) {
      toast.error("Please enter an event name.");
      return;
    }
    const cleanQs: Question[] = questions
      .map((q) => ({
        id: q.id,
        label: q.label.trim(),
        options: q.options.map((o) => o.trim()).filter(Boolean),
      }))
      .filter((q) => q.label && q.options.length > 0);

    const cleanAttendees: Attendee[] = team
      .filter((t) => selectedEmails.has(t.email.toLowerCase()))
      .map((t) => ({
        name: t.name,
        email: t.email,
        slack_id: t.slack_member_id || "",
      }));

    setSaving(true);
    const payload = {
      name: name.trim(),
      meta: meta.trim() || null,
      event_type: eventType || null,
      organizer: organizer.trim() || null,
      start_date: startDate || null,
      end_date: endDate || null,
      questions: cleanQs,
      attendees: cleanAttendees,
    };
    const { error } = editing
      ? await supabase.from("events").update(payload as any).eq("id", editing.id)
      : await supabase.from("events").insert(payload as any);
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    onClose();
  };

  return (
    <div className="sheet-modal" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="sheet-inner">
        <div className="handle" />
        <div className="mhead">
          <h2>{editing ? "Edit Event" : "New Event"}</h2>
          <button className="btn-ico" onClick={onClose}>
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M18 6 6 18M6 6l12 12" />
            </svg>
          </button>
        </div>
        <div className="mbody">
          <div className="fld">
            <label>Event Name *</label>
            <input className="input-os" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. DistribuTECH 2026" />
          </div>
          <div className="fld" style={{ marginTop: 11 }}>
            <label>Location / Date (optional)</label>
            <input className="input-os" value={meta} onChange={(e) => setMeta(e.target.value)} placeholder="e.g. San Diego, Feb 2026" />
          </div>
          <div className="fld" style={{ marginTop: 11 }}>
            <label>Event Type</label>
            <select className="select-os" value={eventType} onChange={(e) => setEventType(e.target.value)}>
              <option value="">Select type</option>
              <option value="Conference">Conference</option>
              <option value="Webinar">Webinar</option>
              <option value="Other">Other</option>
            </select>
          </div>
          <div className="fld" style={{ marginTop: 11 }}>
            <label>Event Organizer</label>
            <input className="input-os" value={organizer} onChange={(e) => setOrganizer(e.target.value)} placeholder="e.g. DISTRIBUTECH International" />
          </div>
          <div className="twocol" style={{ marginTop: 11 }}>
            <div className="fld">
              <label>Start Date</label>
              <input className="input-os" type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
            </div>
            <div className="fld">
              <label>End Date</label>
              <input className="input-os" type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
            </div>
          </div>
          <div className="divider-os" />
          <div className="seclbl">Qualifier Questions</div>
          <p style={{ fontSize: 13, color: "hsl(var(--text-3))", marginBottom: 14 }}>
            Add picklist questions for your team to answer during each scan.
          </p>
          {questions.map((q, idx) => (
            <div className="qb" key={q.id}>
              <div className="qbhead">
                <span style={{ fontSize: 13, fontWeight: 600, color: "hsl(var(--text-2))", flex: 1 }}>
                  Question {idx + 1}
                </span>
                <button
                  className="btn-ico"
                  style={{ width: 28, height: 28, border: "none", background: "transparent", color: "hsl(var(--text-3))" }}
                  onClick={() => removeQ(q.id)}
                >
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <path d="M18 6 6 18M6 6l12 12" />
                  </svg>
                </button>
              </div>
              <div className="qbbody">
                <div className="fld">
                  <label>Question label</label>
                  <input
                    className="input-os"
                    value={q.label}
                    onChange={(e) => updateQ(q.id, { label: e.target.value })}
                    placeholder="e.g. Interest level?"
                  />
                </div>
                <div style={{ marginTop: 10 }}>
                  <label style={{ fontSize: 12, fontWeight: 600, color: "hsl(var(--text-2))", display: "block", marginBottom: 8 }}>
                    Answer options
                  </label>
                  <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 10 }}>
                    {q.options.map((o, i) => (
                      <div className="optrow" key={i}>
                        <input
                          className="input-os"
                          style={{ flex: 1, padding: "9px 12px", fontSize: 14 }}
                          value={o}
                          onChange={(e) => updateOpt(q.id, i, e.target.value)}
                          placeholder="Option text"
                        />
                        <button className="rmopt" onClick={() => removeOpt(q.id, i)}>
                          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                            <path d="M18 6 6 18M6 6l12 12" />
                          </svg>
                        </button>
                      </div>
                    ))}
                  </div>
                  <button className="btn-g" onClick={() => addOpt(q.id)}>+ Add option</button>
                </div>
              </div>
            </div>
          ))}
          <button className="btn-os btn-s btn-full" style={{ gap: 6 }} onClick={addQ}>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M12 5v14M5 12h14" />
            </svg>
            Add Question
          </button>

          <div className="divider-os" />
          <div className="seclbl">Overstory Attendees</div>
          <p style={{ fontSize: 13, color: "hsl(var(--text-3))", marginBottom: 14 }}>
            Select which Overstory team members are attending. Manage the roster in Admin → Team Roster.
          </p>
          {team.length === 0 ? (
            <p style={{ fontSize: 13, color: "hsl(var(--text-3))", textAlign: "center", padding: "12px 0" }}>
              No team members in the roster yet. Add some in Admin → Team Roster.
            </p>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {team.map((t) => {
                const checked = selectedEmails.has(t.email.toLowerCase());
                return (
                  <label
                    key={t.id}
                    className="user-row"
                    style={{ cursor: "pointer", userSelect: "none" }}
                  >
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={() => toggleAttendee(t.email)}
                      style={{ width: 16, height: 16, accentColor: "hsl(var(--brand))", flexShrink: 0 }}
                    />
                    <div style={{ flex: 1, fontSize: 13, wordBreak: "break-all" }}>
                      <strong>{t.name}</strong>
                      <br />
                      <span style={{ color: "hsl(var(--text-3))" }}>{t.email}</span>
                    </div>
                  </label>
                );
              })}
            </div>
          )}

        </div>
        <div className="mfoot">
          <button className="btn-os btn-s" style={{ flex: 1 }} onClick={onClose}>Cancel</button>
          <button className="btn-os btn-p" style={{ flex: 2 }} onClick={save} disabled={saving}>
            {saving ? <div className="spin" /> : "Save Event"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default EventModal;
