import { useEffect, useMemo, useRef, useState } from "react";
import { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import logo from "@/assets/overstory-logo.jpg";
import { toast } from "sonner";
import type { Role } from "@/pages/Index";
import EventModal from "./EventModal";
import UserModal from "./UserModal";
import MyLeads from "./MyLeads";

export type Question = { id: string; label: string; options: string[] };
export type Attendee = { name: string; email: string; slack_id: string };
export type TeamMember = {
  id: string;
  name: string;
  email: string;
  slack_member_id: string | null;
  created_at: string;
};
export type EventRow = {
  id: string;
  name: string;
  meta: string | null;
  event_type: string | null;
  organizer: string | null;
  start_date: string | null;
  end_date: string | null;
  questions: Question[];
  attendees?: Attendee[];
};
export type LeadRow = {
  id: string;
  event_id: string | null;
  event_name: string | null;
  first_name: string | null;
  last_name: string | null;
  email: string | null;
  company: string | null;
  title: string | null;
  answers: Record<string, string>;
  notes: string | null;
  scanned_by: string | null;
  scanned_by_name: string | null;
  created_at: string;
};
export type ApprovedUser = {
  id: string;
  email: string;
  name: string | null;
  role: Role;
};


interface Props {
  user: User;
  role: Role;
  name: string;
}

const LeadApp = ({ user, role, name }: Props) => {
  const [tab, setTab] = useState<"scan" | "mine" | "admin">("scan");
  const [events, setEvents] = useState<EventRow[]>([]);
  const [leads, setLeads] = useState<LeadRow[]>([]);
  const [approved, setApproved] = useState<ApprovedUser[]>([]);
  const [team, setTeam] = useState<TeamMember[]>([]);
  const [curEvId, setCurEvId] = useState<string>("");

  // Team add form
  const [tmName, setTmName] = useState("");
  const [tmEmail, setTmEmail] = useState("");
  const [tmSlack, setTmSlack] = useState("");
  const [tmSaving, setTmSaving] = useState(false);


  // Scan flow state
  const [selFile, setSelFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>("");
  const [extracting, setExtracting] = useState(false);
  const [step, setStep] = useState(1);
  const [showFields, setShowFields] = useState(false);
  const [showQs, setShowQs] = useState(false);
  const [showSubmit, setShowSubmit] = useState(false);
  const [showOk, setShowOk] = useState(false);
  const [okMsg, setOkMsg] = useState("");
  const [first, setFirst] = useState("");
  const [last, setLast] = useState("");
  const [email, setEmail] = useState("");
  const [company, setCompany] = useState("");
  const [title, setTitle] = useState("");
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [notes, setNotes] = useState("");
  const [listening, setListening] = useState(false);
  const recognitionRef = useRef<any>(null);
  const [saving, setSaving] = useState(false);
  const [drag, setDrag] = useState(false);

  // Admin filter
  const [leadFilter, setLeadFilter] = useState<string>("all");

  // Modals
  const [eventModal, setEventModal] = useState<{ open: boolean; editing: EventRow | null }>({
    open: false,
    editing: null,
  });
  const [userModalOpen, setUserModalOpen] = useState(false);

  const fileInput = useRef<HTMLInputElement>(null);

  // Load all data
  const loadAll = async () => {
    const [{ data: ev }, { data: ld }, { data: tm }] = await Promise.all([
      supabase.from("events").select("*").order("created_at", { ascending: true }),
      supabase.from("leads").select("*").order("created_at", { ascending: false }),
      supabase.from("team_members").select("*").order("name", { ascending: true }),
    ]);
    setEvents(((ev as unknown) as EventRow[]) || []);
    setLeads(((ld as unknown) as LeadRow[]) || []);
    setTeam(((tm as unknown) as TeamMember[]) || []);
    if (role === "admin") {
      const { data: au } = await supabase.from("approved_users").select("*").order("created_at");
      setApproved(((au as unknown) as ApprovedUser[]) || []);
    }
  };

  useEffect(() => {
    loadAll();
    // realtime subscriptions
    const ch = supabase
      .channel("app-sync")
      .on("postgres_changes", { event: "*", schema: "public", table: "events" }, () => loadAll())
      .on("postgres_changes", { event: "*", schema: "public", table: "leads" }, () => loadAll())
      .on("postgres_changes", { event: "*", schema: "public", table: "approved_users" }, () => loadAll())
      .on("postgres_changes", { event: "*", schema: "public", table: "team_members" }, () => loadAll())
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [role]);

  const curEvent = useMemo(() => events.find((e) => e.id === curEvId) || null, [events, curEvId]);

  // ---- Scan helpers ----
  const onFile = (f: File) => {
    setSelFile(f);
    const r = new FileReader();
    r.onload = (e) => setPreviewUrl((e.target?.result as string) || "");
    r.readAsDataURL(f);
  };
  const clearPhoto = () => {
    setSelFile(null);
    setPreviewUrl("");
    if (fileInput.current) fileInput.current.value = "";
  };
  const onEvChange = (id: string) => {
    setCurEvId(id);
    setAnswers({});
    setShowFields(false);
    setShowQs(false);
    setShowSubmit(false);
    setShowOk(false);
    clearPhoto();
    setStep(id ? 2 : 1);
  };

  const fillFields = (f: string, l: string, em: string, co: string, ti: string) => {
    setFirst(f);
    setLast(l);
    setEmail(em);
    setCompany(co);
    setTitle(ti);
    setShowFields(true);
    setShowQs(true);
    setShowSubmit(true);
    setStep(3);
    setAnswers({});
    setNotes("");
  };

  const fileToB64 = (file: File) =>
    new Promise<string>((res, rej) => {
      const r = new FileReader();
      r.onload = () => res((r.result as string).split(",")[1]);
      r.onerror = rej;
      r.readAsDataURL(file);
    });

  const doScan = async () => {
    if (!selFile) return;
    setExtracting(true);
    try {
      const b64 = await fileToB64(selFile);
      const { data, error } = await supabase.functions.invoke("extract-card", {
        body: { imageBase64: b64, mediaType: selFile.type },
      });
      if (error) throw error;
      fillFields(
        data?.firstName || "",
        data?.lastName || "",
        data?.email || "",
        data?.company || "",
        data?.title || ""
      );
    } catch (e: unknown) {
      console.warn("Extraction failed, falling back to manual", e);
      toast.error("Could not extract card. Fill in manually.");
      fillFields("", "", "", "", "");
    } finally {
      setExtracting(false);
    }
  };

  const saveLead = async () => {
    if (!first && !last && !email) {
      toast.error("Enter at least a name or email.");
      return;
    }
    setSaving(true);
    const payload = {
      event_id: curEvId || null,
      event_name: curEvent?.name || null,
      first_name: first || null,
      last_name: last || null,
      email: email || null,
      company: company || null,
      title: title || null,
      answers,
      notes: notes.trim() || null,
      scanned_by: user.id,
      scanned_by_name:
        team.find((t) => t.email.toLowerCase() === (user.email || "").toLowerCase())?.name ||
        name ||
        user.email?.split("@")[0] ||
        null,
    };
    const { error } = await supabase.from("leads").insert(payload as any);
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    const display = [first, last].filter(Boolean).join(" ") || email || "Contact";
    setOkMsg(`${display} added to ${curEvent?.name || "this event"}.`);
    setShowFields(false);
    setShowQs(false);
    setShowSubmit(false);
    setShowOk(true);
    setStep(4);
  };

  const resetScan = () => {
    clearPhoto();
    setFirst(""); setLast(""); setEmail(""); setCompany(""); setTitle("");
    setAnswers({}); setNotes("");
    setShowFields(false); setShowQs(false); setShowSubmit(false); setShowOk(false);
    setStep(curEvId ? 2 : 1);
  };

  const signOut = async () => {
    await supabase.auth.signOut();
  };

  const toggleListening = () => {
    if (listening) {
      recognitionRef.current?.stop();
      return;
    }
    const SR: any =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) {
      toast.error("Voice dictation isn't supported in this browser.");
      return;
    }
    const rec = new SR();
    rec.continuous = true;
    rec.interimResults = false;
    rec.lang = navigator.language || "en-US";
    rec.onresult = (e: any) => {
      let chunk = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) chunk += e.results[i][0].transcript;
      }
      if (chunk) {
        setNotes((prev) => (prev ? prev.replace(/\s+$/, "") + " " + chunk.trim() : chunk.trim()));
      }
    };
    rec.onerror = (e: any) => {
      console.warn("SpeechRecognition error", e);
      if (e.error && e.error !== "no-speech" && e.error !== "aborted") {
        toast.error("Dictation error: " + e.error);
      }
    };
    rec.onend = () => setListening(false);
    recognitionRef.current = rec;
    try {
      rec.start();
      setListening(true);
    } catch (err) {
      console.warn(err);
    }
  };


  // ---- Admin actions ----
  const deleteEvent = async (id: string) => {
    const ev = events.find((e) => e.id === id);
    if (!ev) return;
    const n = leads.filter((l) => l.event_id === id).length;
    if (!confirm(`Delete "${ev.name}"?${n ? ` Also removes ${n} lead${n !== 1 ? "s" : ""}.` : ""}`))
      return;
    const { error } = await supabase.from("events").delete().eq("id", id);
    if (error) toast.error(error.message);
    if (curEvId === id) {
      setCurEvId("");
      resetScan();
    }
  };

  const removeUser = async (id: string, em: string) => {
    if (!confirm(`Remove ${em} from the team?`)) return;
    const { error } = await supabase.from("approved_users").delete().eq("id", id);
    if (error) toast.error(error.message);
  };

  const addTeamMember = async () => {
    const n = tmName.trim();
    const em = tmEmail.trim();
    if (!n || !em) {
      toast.error("Name and email are required.");
      return;
    }
    setTmSaving(true);
    const { error } = await supabase.from("team_members").insert({
      name: n,
      email: em,
      slack_member_id: tmSlack.trim() || null,
    } as any);
    setTmSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    setTmName(""); setTmEmail(""); setTmSlack("");
  };

  const removeTeamMember = async (id: string, em: string) => {
    if (!confirm(`Remove ${em} from the team roster?`)) return;
    const { error } = await supabase.from("team_members").delete().eq("id", id);
    if (error) toast.error(error.message);
  };

  // ---- CSV export ----
  const exportCSV = () => {
    const filtered = leadFilter === "all" ? leads : leads.filter((l) => l.event_id === leadFilter);
    if (!filtered.length) {
      toast.error("No leads to export.");
      return;
    }
    const evIds = Array.from(new Set(filtered.map((l) => l.event_id).filter(Boolean) as string[]));
    const qIds: string[] = [];
    const qLbls: Record<string, string> = {};
    evIds.forEach((eid) => {
      const ev = events.find((e) => e.id === eid);
      ev?.questions?.forEach((q) => {
        if (!qIds.includes(q.id)) {
          qIds.push(q.id);
          qLbls[q.id] = q.label;
        }
      });
    });
    const headers = [
      "Date", "Event", "Event Type", "Event Organizer", "Event Start Date", "Event End Date",
      "First Name", "Last Name", "Email", "Company", "Title", "Notes", "Scanned By",
      ...qIds.map((id) => qLbls[id] || id),
    ];
    const rows = filtered.map((l) => {
      const ev = events.find((e) => e.id === l.event_id);
      const date = new Date(l.created_at).toLocaleDateString("en-US", {
        year: "numeric", month: "short", day: "numeric",
      });
      return [
        date, l.event_name || "", ev?.event_type || "", ev?.organizer || "",
        ev?.start_date || "", ev?.end_date || "",
        l.first_name || "", l.last_name || "", l.email || "", l.company || "", l.title || "",
        l.notes || "",
        l.scanned_by_name || "",
        ...qIds.map((id) => l.answers?.[id] || ""),
      ];
    });
    const csv = [headers, ...rows]
      .map((r) => r.map((c) => `"${String(c || "").replace(/"/g, '""')}"`).join(","))
      .join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    const ev = events.find((e) => e.id === leadFilter);
    const fname =
      (leadFilter === "all" ? "all_leads" : (ev?.name || "leads").replace(/\s+/g, "_")) +
      "_" + new Date().toISOString().slice(0, 10) + ".csv";
    a.href = url; a.download = fname; a.click();
    URL.revokeObjectURL(url);
  };

  const filteredLeads = leadFilter === "all" ? leads : leads.filter((l) => l.event_id === leadFilter);

  return (
    <div className="app-shell">
      {/* TOPBAR */}
      <div className="topbar">
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <img src={logo} alt="Overstory" style={{ height: 28, width: "auto" }} />
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div className="role-pill">
            {(name || user.email?.split("@")[0]) + " · " + (role === "admin" ? "Admin" : "Scanner")}
          </div>
          {role === "admin" ? (
            <div className="tabs">
              <button className={"tab" + (tab === "scan" ? " on" : "")} onClick={() => setTab("scan")}>Scan</button>
              <button className={"tab" + (tab === "mine" ? " on" : "")} onClick={() => setTab("mine")}>My Leads</button>
              <button className={"tab" + (tab === "admin" ? " on" : "")} onClick={() => setTab("admin")}>Admin</button>
            </div>
          ) : (
            <div className="tabs">
              <button className={"tab" + (tab === "scan" ? " on" : "")} onClick={() => setTab("scan")}>Scan</button>
              <button className={"tab" + (tab === "mine" ? " on" : "")} onClick={() => setTab("mine")}>My Leads</button>
            </div>
          )}
        </div>
      </div>

      {/* SCAN VIEW */}
      {tab === "scan" && (
        <div className="view">
          <div className="stepbar">
            {[1, 2, 3, 4].map((n) => (
              <div key={n} className={"seg" + (n < step ? " done" : n === step ? " now" : "")} />
            ))}
          </div>

          <div className="card-os">
            <div className="clabel">Select Event</div>
            {events.length === 0 ? (
              <div style={{ textAlign: "center", padding: "28px 16px" }}>
                <h3 className="font-heading" style={{ fontSize: 16, fontWeight: 700, marginBottom: 5 }}>
                  No events yet
                </h3>
                <p style={{ fontSize: 13, color: "hsl(var(--text-3))" }}>
                  {role === "admin"
                    ? "Create an event in the Admin tab first."
                    : "No events set up yet. Ask your admin."}
                </p>
              </div>
            ) : (
              <select className="select-os" value={curEvId} onChange={(e) => onEvChange(e.target.value)}>
                <option value="">Choose an event</option>
                {[...events].reverse().map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.name}
                    {e.meta ? ` · ${e.meta}` : ""}
                  </option>
                ))}
              </select>
            )}
          </div>

          {curEvId && !showOk && (
            <div className="card-os">
              <div className="clabel">Scan Business Card</div>
              {!previewUrl ? (
                <div
                  className={"uzone" + (drag ? " lit" : "")}
                  onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
                  onDragLeave={() => setDrag(false)}
                  onDrop={(e) => {
                    e.preventDefault(); setDrag(false);
                    const f = e.dataTransfer.files[0];
                    if (f && f.type.startsWith("image/")) onFile(f);
                  }}
                >
                  <input
                    ref={fileInput}
                    type="file"
                    accept="image/*"
                    capture="environment"
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) onFile(f);
                    }}
                  />
                  <div className="uico">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="hsl(var(--brand))" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                      <rect x="3" y="3" width="18" height="18" rx="3" />
                      <circle cx="9" cy="9" r="2" />
                      <path d="m21 15-5-5L5 21" />
                    </svg>
                  </div>
                  <h3 className="font-heading" style={{ fontSize: 15, fontWeight: 700, marginBottom: 4 }}>
                    Take a photo
                  </h3>
                  <p style={{ fontSize: 13, color: "hsl(var(--text-3))" }}>Or tap to upload from library</p>
                </div>
              ) : (
                <>
                  <img
                    src={previewUrl}
                    alt="Card preview"
                    style={{
                      width: "100%", borderRadius: 10, maxHeight: 200, objectFit: "contain",
                      border: "1.5px solid hsl(var(--border-soft))",
                    }}
                  />
                  <div style={{ display: "flex", gap: 10, marginTop: 12 }}>
                    <button className="btn-os btn-s" style={{ flex: 1 }} onClick={clearPhoto}>
                      Change
                    </button>
                    <button className="btn-os btn-p" style={{ flex: 2 }} onClick={doScan} disabled={extracting}>
                      {extracting ? (
                        <>
                          <div className="spin" /> Extracting...
                        </>
                      ) : (
                        <>
                          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
                            <path d="M3 7V5a2 2 0 0 1 2-2h2" />
                            <path d="M17 3h2a2 2 0 0 1 2 2v2" />
                            <path d="M21 17v2a2 2 0 0 1-2 2h-2" />
                            <path d="M7 21H5a2 2 0 0 1-2-2v-2" />
                            <rect x="7" y="7" width="10" height="10" rx="1" />
                          </svg>
                          Extract Contact Info
                        </>
                      )}
                    </button>
                  </div>
                </>
              )}
              <div style={{ marginTop: 12 }}>
                <button className="btn-os btn-s btn-full" onClick={() => fillFields("", "", "", "", "")}>
                  Enter Manually
                </button>
              </div>
            </div>
          )}

          {showFields && (
            <div className="card-os">
              <div className="clabel">Review Details</div>
              <div className="twocol">
                <div className="fld">
                  <label>First Name</label>
                  <input className="input-os" value={first} onChange={(e) => setFirst(e.target.value)} placeholder="First" />
                </div>
                <div className="fld">
                  <label>Last Name</label>
                  <input className="input-os" value={last} onChange={(e) => setLast(e.target.value)} placeholder="Last" />
                </div>
              </div>
              <div className="fld" style={{ marginTop: 11 }}>
                <label>Email</label>
                <input className="input-os" type="email" autoCapitalize="none" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="email@company.com" />
              </div>
              <div className="fld" style={{ marginTop: 11 }}>
                <label>Company</label>
                <input className="input-os" value={company} onChange={(e) => setCompany(e.target.value)} placeholder="Company name" />
              </div>
              <div className="fld" style={{ marginTop: 11 }}>
                <label>Title</label>
                <input className="input-os" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Job title" />
              </div>
            </div>
          )}

          {showQs && curEvent?.questions?.length ? (
            <div className="card-os">
              <div className="clabel">Qualifier Questions</div>
              {curEvent.questions.map((q) => (
                <div key={q.id} style={{ marginBottom: 18 }}>
                  <span style={{ fontSize: 14, fontWeight: 500, marginBottom: 10, display: "block" }}>{q.label}</span>
                  <div className="pillrow">
                    {q.options.map((opt) => (
                      <div
                        key={opt}
                        className={"pill" + (answers[q.id] === opt ? " on" : "")}
                        onClick={() => setAnswers({ ...answers, [q.id]: opt })}
                      >
                        {opt}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          ) : null}



          {showQs && (
            <div className="card-os">
              <div className="clabelrow">
                <div className="clabel" style={{ marginBottom: 0 }}>Notes</div>
                <button
                  type="button"
                  className={"btn-os btn-s" + (listening ? " btn-p" : "")}
                  style={{ padding: "8px 12px", fontSize: 13, gap: 6 }}
                  onClick={toggleListening}
                  title={listening ? "Stop dictation" : "Start voice dictation"}
                >
                  {listening ? (
                    <>
                      <span className="rec-dot" />
                      Listening…
                    </>
                  ) : (
                    <>
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <rect x="9" y="2" width="6" height="12" rx="3" />
                        <path d="M5 10a7 7 0 0 0 14 0" />
                        <line x1="12" y1="19" x2="12" y2="22" />
                      </svg>
                      Dictate
                    </>
                  )}
                </button>
              </div>
              <textarea
                className="input-os"
                rows={4}
                style={{ resize: "vertical", minHeight: 90, fontFamily: "inherit" }}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Add any context from your conversation..."
              />
              {listening && (
                <p style={{ fontSize: 12, color: "hsl(var(--brand))", marginTop: 8 }}>
                  Listening… speak now. Tap the button again to stop.
                </p>
              )}
            </div>
          )}


          {showSubmit && (
            <button className="btn-os btn-p btn-full" onClick={saveLead} disabled={saving}>
              {saving ? <><div className="spin" /> Saving...</> : "Save Lead"}
            </button>
          )}

          {showOk && (
            <div className="card-os">
              <div style={{ textAlign: "center", padding: "10px 0" }}>
                <div className="checkcircle">
                  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="hsl(var(--brand))" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M20 6 9 17l-5-5" />
                  </svg>
                </div>
                <h3 className="font-heading" style={{ fontSize: 22, fontWeight: 800, marginBottom: 6 }}>
                  Lead saved!
                </h3>
                <p style={{ fontSize: 14, color: "hsl(var(--text-2))", marginBottom: 20 }}>{okMsg}</p>
                <button className="btn-os btn-p btn-full" onClick={resetScan}>
                  Scan another card
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ADMIN VIEW */}
      {tab === "admin" && role === "admin" && (
        <div className="view">
          <div className="seclbl">Live Sync</div>
          <div className="card-os">
            <div className="sync-bar sync-ok">
              <div className="dotg" /> Real-time sync active across all devices
            </div>
            <p style={{ fontSize: 13, color: "hsl(var(--text-3))" }}>
              All leads, events, and team changes update instantly for everyone signed in.
            </p>
          </div>

          <div className="seclbl">Anthropic API</div>
          <div className="card-os">
            <div className="apirow apiok">
              <div className="dotg" />
              API key stored securely on the server (set via Lovable Cloud secret <code>ANTHROPIC_API_KEY</code>)
            </div>
            <p style={{ fontSize: 13, color: "hsl(var(--text-3))" }}>
              To rotate the key, update the <code>ANTHROPIC_API_KEY</code> secret in Cloud settings.
            </p>
          </div>

          <div className="seclbl">Team Access</div>
          <div className="card-os">
            <div className="clabelrow">
              <div className="clabel">Approved Users</div>
              <button
                className="btn-os btn-s"
                style={{ padding: "8px 13px", fontSize: 13, gap: 5 }}
                onClick={() => setUserModalOpen(true)}
              >
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <path d="M12 5v14M5 12h14" />
                </svg>
                Add User
              </button>
            </div>
            <p style={{ fontSize: 13, color: "hsl(var(--text-3))", marginBottom: 12 }}>
              Pre-approve email addresses. Users sign up with that email to gain access with the chosen role.
            </p>
            {approved.length === 0 ? (
              <p style={{ fontSize: 13, color: "hsl(var(--text-3))", textAlign: "center", padding: "12px 0" }}>
                No approved users yet.
              </p>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {approved.map((u) => (
                  <div className="user-row" key={u.id}>
                    <div style={{ flex: 1, fontSize: 13, wordBreak: "break-all" }}>
                      {u.name && <><strong>{u.name}</strong><br /></>}
                      {u.email}
                    </div>
                    <span className={"user-role " + (u.role === "admin" ? "role-admin" : "role-scanner")}>
                      {u.role}
                    </span>
                    <button className="btn-ico del" title="Remove" onClick={() => removeUser(u.id, u.email)}>
                      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <polyline points="3 6 5 6 21 6" />
                        <path d="M19 6l-1 14H6L5 6" />
                        <path d="M10 11v6M14 11v6" />
                        <path d="M9 6V4h6v2" />
                      </svg>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="seclbl">Events</div>
          <div className="card-os">
            <div className="clabelrow">
              <div className="clabel">Your Events</div>
              <button
                className="btn-os btn-s"
                style={{ padding: "8px 13px", fontSize: 13, gap: 5 }}
                onClick={() => setEventModal({ open: true, editing: null })}
              >
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <path d="M12 5v14M5 12h14" />
                </svg>
                New Event
              </button>
            </div>
            {events.length === 0 ? (
              <p style={{ fontSize: 13, color: "hsl(var(--text-3))", textAlign: "center", padding: "16px 0" }}>
                No events yet.
              </p>
            ) : (
              events.map((ev) => {
                const n = leads.filter((l) => l.event_id === ev.id).length;
                return (
                  <div className="evrow" key={ev.id}>
                    <div className="evdot" />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <h4 className="font-heading" style={{ fontSize: 15, fontWeight: 700, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                        {ev.name}
                      </h4>
                      <span style={{ fontSize: 12, color: "hsl(var(--text-3))" }}>
                        {ev.meta ? ev.meta + " · " : ""}
                        {n} lead{n !== 1 ? "s" : ""} · {ev.questions.length} question
                        {ev.questions.length !== 1 ? "s" : ""}
                      </span>
                    </div>
                    <div style={{ display: "flex", gap: 7 }}>
                      <button className="btn-ico" onClick={() => setEventModal({ open: true, editing: ev })}>
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                          <path d="M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4Z" />
                        </svg>
                      </button>
                      <button className="btn-ico del" onClick={() => deleteEvent(ev.id)}>
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <polyline points="3 6 5 6 21 6" />
                          <path d="M19 6l-1 14H6L5 6" />
                          <path d="M10 11v6M14 11v6" />
                          <path d="M9 6V4h6v2" />
                        </svg>
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          <div className="seclbl">Team Roster</div>
          <div className="card-os">
            <div className="clabel">Overstory Team Members</div>
            <p style={{ fontSize: 13, color: "hsl(var(--text-3))", marginBottom: 12 }}>
              Master list of Overstory staff. Used to populate event attendee pickers and link captured leads to people.
            </p>
            <div className="twocol">
              <div className="fld">
                <label>Name</label>
                <input className="input-os" value={tmName} onChange={(e) => setTmName(e.target.value)} placeholder="Full name" />
              </div>
              <div className="fld">
                <label>Email</label>
                <input className="input-os" type="email" autoCapitalize="none" value={tmEmail} onChange={(e) => setTmEmail(e.target.value)} placeholder="name@overstory.com" />
              </div>
            </div>
            <div className="fld" style={{ marginTop: 11 }}>
              <label>Slack Member ID</label>
              <input className="input-os" value={tmSlack} onChange={(e) => setTmSlack(e.target.value)} placeholder="e.g. U01ABCDEF" />
              <p style={{ fontSize: 11, color: "hsl(var(--text-3))", marginTop: 5 }}>
                Find in Slack under Profile → More → Copy member ID
              </p>
            </div>
            <button
              className="btn-os btn-p btn-full"
              style={{ marginTop: 12, gap: 6 }}
              onClick={addTeamMember}
              disabled={tmSaving}
            >
              {tmSaving ? <div className="spin" /> : (
                <>
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <path d="M12 5v14M5 12h14" />
                  </svg>
                  Add Team Member
                </>
              )}
            </button>
            <div style={{ marginTop: 16 }}>
              {team.length === 0 ? (
                <p style={{ fontSize: 13, color: "hsl(var(--text-3))", textAlign: "center", padding: "12px 0" }}>
                  No team members yet.
                </p>
              ) : (
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {team.map((t) => (
                    <div className="user-row" key={t.id}>
                      <div style={{ flex: 1, fontSize: 13, wordBreak: "break-all" }}>
                        <strong>{t.name}</strong><br />
                        {t.email}
                        {t.slack_member_id && (
                          <>
                            <br />
                            <span style={{ fontSize: 11, color: "hsl(var(--text-3))" }}>
                              Slack: {t.slack_member_id}
                            </span>
                          </>
                        )}
                      </div>
                      <button className="btn-ico del" title="Remove" onClick={() => removeTeamMember(t.id, t.email)}>
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <polyline points="3 6 5 6 21 6" />
                          <path d="M19 6l-1 14H6L5 6" />
                          <path d="M10 11v6M14 11v6" />
                          <path d="M9 6V4h6v2" />
                        </svg>
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="seclbl">Leads &amp; Export</div>
          <div className="card-os">
            <div className="clabelrow">
              <div className="clabel">All Captured Leads</div>
              <span className="countpill">
                {filteredLeads.length} lead{filteredLeads.length !== 1 ? "s" : ""}
              </span>
            </div>
            <div className="fld" style={{ marginBottom: 13 }}>
              <label>Filter by Event</label>
              <select className="select-os" value={leadFilter} onChange={(e) => setLeadFilter(e.target.value)}>
                <option value="all">All Events</option>
                {events.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.name}
                  </option>
                ))}
              </select>
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <button className="btn-os btn-p" style={{ flex: 1 }} onClick={loadAll}>
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
                  <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
                  <path d="M21 3v5h-5" />
                  <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" />
                  <path d="M8 16H3v5" />
                </svg>
                Refresh
              </button>
              <button className="btn-os btn-p" style={{ flex: 1 }} onClick={exportCSV}>
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                  <polyline points="7 10 12 15 17 10" />
                  <line x1="12" y1="15" x2="12" y2="3" />
                </svg>
                Export CSV
              </button>
            </div>
            {filteredLeads.length === 0 ? (
              <div style={{ textAlign: "center", padding: 24, fontSize: 13, color: "hsl(var(--text-3))" }}>
                No leads yet.
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: 10, marginTop: 14 }}>
                {filteredLeads.map((l) => {
                  const fullName = [l.first_name, l.last_name].filter(Boolean).join(" ") || "—";
                  const date = new Date(l.created_at).toLocaleDateString("en-US", {
                    year: "numeric", month: "short", day: "numeric",
                  });
                  const qTags = Object.entries(l.answers || {}).map(([k, v]) => (
                    <span key={k} className="tag">{String(v)}</span>
                  ));
                  return (
                    <div className="leadcard" key={l.id}>
                      <div className="font-heading" style={{ fontSize: 15, fontWeight: 700, marginBottom: 2 }}>
                        {fullName}
                      </div>
                      <div style={{ fontSize: 13, color: "hsl(var(--brand-mid))", marginBottom: 5 }}>
                        {l.email || "—"}
                      </div>
                      <div style={{ fontSize: 12, color: "hsl(var(--text-3))", marginBottom: 6 }}>
                        {l.company || ""}
                        {l.company && l.title ? " · " : ""}
                        {l.title || ""}
                        {l.company || l.title ? "  ·  " : ""}
                        {l.event_name ? l.event_name + "  ·  " : ""}
                        {date}
                      </div>
                      {l.scanned_by_name && (
                        <div style={{ fontSize: 11, color: "hsl(var(--text-3))", marginBottom: 6, opacity: 0.8 }}>
                          Captured by {l.scanned_by_name}
                        </div>
                      )}
                      {qTags.length > 0 && (
                        <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
                          {qTags}
                        </div>
                      )}
                      {l.notes && (
                        <div style={{
                          marginTop: 8, fontSize: 12, color: "hsl(var(--text-2))",
                          display: "flex", gap: 6, alignItems: "flex-start", opacity: 0.85,
                          padding: "8px 10px", background: "hsl(var(--border-soft) / 0.4)", borderRadius: 8,
                        }}>
                          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ flexShrink: 0, marginTop: 1 }}>
                            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                            <polyline points="14 2 14 8 20 8" />
                            <line x1="8" y1="13" x2="16" y2="13" />
                            <line x1="8" y1="17" x2="13" y2="17" />
                          </svg>
                          <span style={{ whiteSpace: "pre-wrap", wordBreak: "break-word" }}>{l.notes}</span>
                        </div>
                      )}
                    </div>

                  );
                })}
              </div>
            )}
          </div>

          <div style={{ textAlign: "center", paddingBottom: 8 }}>
            <button className="btn-g" onClick={signOut}>Sign out</button>
          </div>
        </div>
      )}

      {/* MY LEADS VIEW */}
      {tab === "mine" && (
        <MyLeads userId={user.id} leads={leads} events={events} onUpdated={loadAll} />
      )}

      {tab !== "admin" && (
        <div style={{ textAlign: "center", padding: "12px 0 24px" }}>
          <button className="btn-g" onClick={signOut}>Sign out</button>
        </div>
      )}

      {/* MODALS */}
      {eventModal.open && (
        <EventModal
          editing={eventModal.editing}
          team={team}
          onClose={() => setEventModal({ open: false, editing: null })}
        />
      )}
      {userModalOpen && <UserModal onClose={() => setUserModalOpen(false)} />}
    </div>
  );
};

export default LeadApp;
