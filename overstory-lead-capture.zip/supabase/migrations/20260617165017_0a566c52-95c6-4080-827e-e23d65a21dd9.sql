ALTER TABLE public.leads ADD COLUMN notes text;
ALTER TABLE public.events ADD COLUMN attendees jsonb NOT NULL DEFAULT '[]'::jsonb;