-- Roles enum + table
CREATE TYPE public.app_role AS ENUM ('admin', 'scanner');

CREATE TABLE public.profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  name TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Approved emails: admins pre-approve people; on signup, role gets assigned
CREATE TABLE public.approved_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL UNIQUE,
  name TEXT,
  role app_role NOT NULL DEFAULT 'scanner',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.approved_users ENABLE ROW LEVEL SECURITY;

-- Seed first admin
INSERT INTO public.approved_users (email, name, role) VALUES ('rebecca.reed@overstory.com', 'Becca Reed', 'admin');

-- Security definer for role checks
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

-- Trigger: on new user, create profile + assign role from approved_users (default scanner)
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _approved approved_users%ROWTYPE;
  _assigned_role app_role;
  _name TEXT;
BEGIN
  SELECT * INTO _approved FROM public.approved_users WHERE LOWER(email) = LOWER(NEW.email);
  IF _approved.id IS NULL THEN
    _assigned_role := 'scanner';
    _name := NEW.raw_user_meta_data ->> 'name';
  ELSE
    _assigned_role := _approved.role;
    _name := COALESCE(_approved.name, NEW.raw_user_meta_data ->> 'name');
  END IF;

  INSERT INTO public.profiles (user_id, email, name) VALUES (NEW.id, NEW.email, _name);
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, _assigned_role);
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Function: only allow login for approved users (or first user becomes admin if no approved list)
-- We'll enforce approval on the client by checking approved_users prior to signup;
-- And block sign-in if not present. To keep it clean, we use a check function.
CREATE OR REPLACE FUNCTION public.is_email_approved(_email TEXT)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (SELECT 1 FROM public.approved_users WHERE LOWER(email) = LOWER(_email))
$$;

-- Profiles policies: any authenticated user can see profiles (small team) and update own
CREATE POLICY "Authenticated can view profiles" ON public.profiles
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "User updates own profile" ON public.profiles
  FOR UPDATE TO authenticated USING (auth.uid() = user_id);

-- user_roles: anyone authenticated can read (to know who is admin); only admins can modify
CREATE POLICY "Authenticated can view roles" ON public.user_roles
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins manage roles" ON public.user_roles
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- approved_users: only admins read/write
CREATE POLICY "Admins view approved users" ON public.approved_users
  FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins manage approved users" ON public.approved_users
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Events
CREATE TABLE public.events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  meta TEXT,
  event_type TEXT,
  organizer TEXT,
  start_date DATE,
  end_date DATE,
  questions JSONB NOT NULL DEFAULT '[]'::JSONB,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated view events" ON public.events
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins manage events" ON public.events
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Leads
CREATE TABLE public.leads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id UUID REFERENCES public.events(id) ON DELETE SET NULL,
  event_name TEXT,
  first_name TEXT,
  last_name TEXT,
  email TEXT,
  company TEXT,
  title TEXT,
  answers JSONB NOT NULL DEFAULT '{}'::JSONB,
  scanned_by UUID REFERENCES auth.users(id),
  scanned_by_name TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.leads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated view all leads" ON public.leads
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated insert leads" ON public.leads
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = scanned_by);
CREATE POLICY "Admins update leads" ON public.leads
  FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins delete leads" ON public.leads
  FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- Updated_at trigger for events
CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE TRIGGER events_touch BEFORE UPDATE ON public.events
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.events;
ALTER PUBLICATION supabase_realtime ADD TABLE public.leads;
ALTER PUBLICATION supabase_realtime ADD TABLE public.approved_users;
ALTER TABLE public.events REPLICA IDENTITY FULL;
ALTER TABLE public.leads REPLICA IDENTITY FULL;
ALTER TABLE public.approved_users REPLICA IDENTITY FULL;